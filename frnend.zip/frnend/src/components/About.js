import "./About.css"
let About=()=>{
    return(
        <div>
        <h2>About Us</h2>
      <p>
        Welcome to our website! This is the about page where you can learn more
        about our company or organization.
      </p>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla
        malesuada libero ac volutpat. Quisque et urna sit amet risus
        condimentum fermentum. Sed suscipit vestibulum tortor, nec vulputate
        odio interdum a. Nulla facilisi.
      </p>
        </div>
    )
}
export default About