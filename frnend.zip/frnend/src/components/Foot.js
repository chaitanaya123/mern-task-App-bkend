import './Foot.css'
let Foot=()=>{
    return(
        <div className='foot'>@TATALakshmiChaitanyacopyrights</div>
    )
}
export default Foot;