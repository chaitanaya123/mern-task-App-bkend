import {createContext} from 'react'
let Gc=createContext({})
export default Gc